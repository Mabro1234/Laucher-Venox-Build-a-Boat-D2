; Скрипт сборки инсталлера Venrox Launcher (.exe версия)
[Setup]
AppName=Venrox Launcher
AppVersion=1.0.3
AppId={{VenroxLauncher_Exe_ID_2026}
DefaultDirName={userdesktop}\VenroxLauncher
DefaultGroupName=Venrox Launcher
UninstallDisplayIcon={app}\launcher.exe
OutputBaseFilename=VenroxLauncher_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=no
DisableDirPage=no
DisableFinishedPage=no

[Files]
; Упаковываем скомпилированный launcher.exe прямо внутрь установщика
Source: "launcher.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
; Создаем прямые ярлыки на лаунчер
Name: "{autoprograms}\Venrox Launcher"; Filename: "{app}\launcher.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\Venrox Launcher"; Filename: "{app}\launcher.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked